#### Chapter 2. Find Missing Reactives ####

library(shiny)
library(ggplot2)
library(dplyr)
library(tools)
load(url("http://s3.amazonaws.com/assets.datacamp.com/production/course_4850/datasets/movies.Rdata"))

# Define UI for application that plots features of movies
ui <- fluidPage(
  
  # Application title
  titlePanel("Movie Browser"),
  
  # Sidebar layout with a input and output definitions
  sidebarLayout(
    
    # Inputs(s)
    sidebarPanel(
      
      # Select variable for y-axis
      selectInput(
        inputId = "y", 
        label = "Y-axis:", 
        choices = c("IMDB rating" = "imdb_rating", 
                    "IMDB number of votes" = "imdb_num_votes", 
                    "Critics Score" = "critics_score", 
                    "Audience Score" = "audience_score", 
                    "Runtime" = "runtime"), 
        selected = "audience_score"
      ), 
      
      # Select variable for y-axis
      selectInput(
        inputId = "x", 
        label = "X-axis:", 
        choices = c("IMDB rating" = "imdb_rating", 
                    "IMDB number of votes" = "imdb_num_votes", 
                    "Critics Score" = "critics_score", 
                    "Audience Score" = "audience_score", 
                    "Runtime" = "runtime"), 
        selected = "critics_score"
      ),
      
      # Select variable for color
      selectInput(inputId = "z", 
                  label = "Color by:",
                  choices = c("Title Type" = "title_type", 
                              "Genre" = "genre", 
                              "MPAA Rating" = "mpaa_rating", 
                              "Critics Rating" = "critics_rating", 
                              "Audience Rating" = "audience_rating"),
                  selected = "mpaa_rating"),
      
      # Enter text for plot title
      textInput(
        inputId = "plot_title", 
        label = "Plot title", 
        placeholder = "Enter text for plot title"
      ), 
      
      # Select which types of movies to plot
      checkboxGroupInput(
        inputId = "selected_type", 
        label = "Select movie type(s):",
        choices = c("Documentary", "Feature Film", "TV Movie"), 
        selected = "Feature Film"
      )
    ), # sidebarPanel
    
    # Output(s)
    mainPanel(
      plotOutput(outputId = "scatterplot"), 
      textOutput(outputId = "description")
    ) # mainPanel
  ) # sidebarLayout
) # fluidPage

# Server
server <- function(input, output) {
  
  # Create a subset of data filtering for selected title types
  movies_subset <- reactive({
    req(input$selected_type)
    filter(movies, title_type %in% input$selected_type)
  })
  
  # Convert plot_title toTitleCase
  pretty_plot_title <- toTitleCase(input$plot_title) # library(tools)
  
  # Create scatterplot object the plotOutput function is expecting
  output$scatterplot <- renderPlot({
    ggplot(data = movies_subset, 
           aes_string(x = input$x, y = input$y, color = input$y)) + 
      geom_point() + 
      labs(title = pretty_plot_title)
  })
  
  # Create descriptive text
  output$description <- renderText({
    paste0("The plot above titled '", pretty_plot_title, "' visualizes the relationship between", input$x, " and ", input$y, ", conditional on ", input$z, ".")
  })
}

# Create the Shiny app object
shinyApp(ui = ui, server = server )

#### Instructions ####
# Debug the app making sure reactives are being used correctly.
