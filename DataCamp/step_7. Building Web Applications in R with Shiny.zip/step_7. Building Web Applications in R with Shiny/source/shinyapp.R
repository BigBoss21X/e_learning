load(url("https://raw.githubusercontent.com/amrrs/sample_revenue_dashboard_shiny/master/recommendation.csv"))
